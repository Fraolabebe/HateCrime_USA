All code were written in python. We started by importing the dataset Hate_crime found under Resources folder. After processing and cleaning
the dataset was saved as cleaned_data for the purpose of visualizations. Some visualizations were built using tableau, and the dataset used
for building this visuals in tablea was the cleaned_data